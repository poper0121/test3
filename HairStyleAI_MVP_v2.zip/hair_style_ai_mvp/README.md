# Hair Style AI MVP

Flutterで動くMVPデモです。

## 現在できること

- ホーム
- カメラ / 写真選択
- 自撮り画像表示
- デモ分析
- 顔型 / 毛量 / 髪の太さ / ボリューム / クセ / 長さ / 信頼度の表示
- 12種類程度の髪型一覧
- 髪型選択
- AI試着画面（UIデモ）
- 美容師オーダーカード
- スタイリング剤表示
- 30秒セット表示

## 重要

現段階ではAI API、Backend、PostgreSQL、実際の画像生成APIは未接続です。
「AI試着デモ」は実画像を生成していません。

## 起動

Flutter SDKをインストール後、このフォルダで:

flutter pub get
flutter run

iOS:
cd ios
pod install
cd ..
flutter run

Android:
flutter run
