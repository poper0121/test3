import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const HairStyleAI());

class HairStyleAI extends StatelessWidget {
  const HairStyleAI({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hair Style AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff292521)),
        scaffoldBackgroundColor: const Color(0xfff6f3ef),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hair Style AI')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 30),
          const Text('自分に似合う髪型を\nAIで見つけよう',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          const Text('自撮りから髪の状態・顔型を分析し、似合う髪型を提案するMVPデモです。',
              style: TextStyle(fontSize: 15, height: 1.6)),
          const SizedBox(height: 35),
          FilledButton.icon(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DiagnosisPage())),
            icon: const Icon(Icons.camera_alt_outlined),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 15),
              child: Text('自撮りして診断', style: TextStyle(fontSize: 17)),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const StylesPage())),
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 13),
              child: Text('髪型を見る'),
            ),
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavigationBar(
        currentIndex: 0,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'ホーム'),
          BottomNavigationBarItem(icon: Icon(Icons.content_cut), label: '髪型'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: '履歴'),
        ],
      ),
    );
  }
}

class DiagnosisPage extends StatefulWidget {
  const DiagnosisPage({super.key});
  @override
  State<DiagnosisPage> createState() => _DiagnosisPageState();
}

class _DiagnosisPageState extends State<DiagnosisPage> {
  File? image;
  bool analyzing = false;
  final picker = ImagePicker();

  Future<void> pick(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 85);
    if (x != null) setState(() => image = File(x.path));
  }

  Future<void> analyze() async {
    setState(() => analyzing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => analyzing = false);
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => const ResultPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI髪診断')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('1. 自撮り', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text('正面・顔全体・髪全体が写る写真がおすすめです。'),
          const SizedBox(height: 18),
          Container(
            height: 330,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            clipBehavior: Clip.antiAlias,
            child: image == null
                ? const Center(child: Text('写真を選択してください'))
                : Image.file(image!, fit: BoxFit.cover),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => pick(ImageSource.camera),
              icon: const Icon(Icons.camera_alt),
              label: const Text('カメラ'),
            )),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => pick(ImageSource.gallery),
              icon: const Icon(Icons.photo),
              label: const Text('写真から'),
            )),
          ]),
          const SizedBox(height: 20),
          if (image != null)
            FilledButton(
              onPressed: analyzing ? null : analyze,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: analyzing
                    ? const SizedBox(height: 20, width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('この写真をAI分析する'),
              ),
            ),
          const SizedBox(height: 14),
          const Notice(text: '現在のMVPでは分析結果をデモ値で表示しています。実AI APIは未接続です。'),
        ],
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  const ResultPage({super.key});
  @override
  Widget build(BuildContext context) {
    final values = [
      ['顔型', '卵型寄り'],
      ['毛量', '62 / 100'],
      ['髪の太さ', '55 / 100'],
      ['ボリューム', '58 / 100'],
      ['クセ', '30 / 100'],
      ['現在の長さ', 'ミディアム'],
      ['診断信頼度', '78%'],
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('診断結果')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('AI髪診断', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, childAspectRatio: 2.2, crossAxisSpacing: 10, mainAxisSpacing: 10),
            itemCount: values.length,
            itemBuilder: (_, i) => Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(values[i][0], style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 4),
                    Text(values[i][1], style: const TextStyle(fontWeight: FontWeight.bold)),
                  ]),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Notice(text: '毛量は写真からの相対推定です。実際の毛髪本数を測定するものではありません。'),
          const SizedBox(height: 28),
          const Text('あなたへのおすすめ', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          StyleCard(name: 'ナチュラルショート', score: '95%', reason: 'トップを盛りすぎず、輪郭をすっきり見せやすいスタイル。'),
          StyleCard(name: 'センターパート', score: '94%', reason: '卵型と相性がよく、現在の毛量でも作りやすいスタイル。'),
          StyleCard(name: '軽めマッシュ', score: '90%', reason: '前髪で輪郭を柔らかく見せながら重くなりすぎない形。'),
        ],
      ),
    );
  }
}

class StyleCard extends StatelessWidget {
  final String name, score, reason;
  const StyleCard({super.key, required this.name, required this.score, required this.reason});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(17),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('おすすめ $score', style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 8),
        Text(reason),
        const SizedBox(height: 12),
        OutlinedButton(
          onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => TryOnPage(styleName: name))),
          child: const Text('この髪型を自分の顔で試す'),
        )
      ]),
    ),
  );
}

class StylesPage extends StatelessWidget {
  const StylesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final groups = {
      'トレンド': ['トレンドショート', 'トレンドミディ'],
      'ショート': ['ナチュラルショート', '軽めマッシュ', 'アップバング', 'ソフトツーブロック'],
      'ミディアム': ['センターパート', 'レイヤーミディ', 'ニュアンスパーマ風', 'ナチュラルウルフ'],
      'ロング': ['ロングレイヤー', 'センターパートロング'],
    };
    return Scaffold(
      appBar: AppBar(title: const Text('髪型')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: groups.entries.map((e) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(padding: const EdgeInsets.only(top: 12, bottom: 10),
              child: Text(e.key, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            ...e.value.map((s) => ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              title: Text(s),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => TryOnPage(styleName: s))),
            )),
            const SizedBox(height: 8),
          ],
        )).toList(),
      ),
    );
  }
}

class TryOnPage extends StatelessWidget {
  final String styleName;
  const TryOnPage({super.key, required this.styleName});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI試着')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(styleName, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          Container(
            height: 360,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
            child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.auto_awesome, size: 55),
              SizedBox(height: 12),
              Text('AI試着デモ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('ここに実AI生成画像が表示されます'),
            ])),
          ),
          const SizedBox(height: 15),
          const Notice(text: '実AI接続時は、本人の顔・構図をできるだけ維持して髪型を変更します。現在はデモ画面です。'),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => BarberCardPage(styleName: styleName))),
            child: const Padding(padding: EdgeInsets.symmetric(vertical: 14),
              child: Text('この髪型に決める')),
          ),
        ],
      ),
    );
  }
}

class BarberCardPage extends StatelessWidget {
  final String styleName;
  const BarberCardPage({super.key, required this.styleName});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('美容師オーダーカード')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('美容師に見せる内容', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('髪型', style: TextStyle(color: Colors.grey)),
              Text(styleName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const Divider(height: 28),
              const Text('長さ目安', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 8),
              const Text('TOP：8〜10cm\nSIDE：3〜5cm\nBACK：4〜6cm\nFRONT：7〜9cm\nNAPE：2〜4cm'),
              const Divider(height: 28),
              const Text('希望', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 8),
              const Text('・毛量は現在の状態を維持\n・サイドは膨らませない\n・トップは自然な立体感\n・ナチュラルな質感'),
            ],
          ))),
          const SizedBox(height: 12),
          const Notice(text: '長さは目安です。頭の形・髪質・現在の長さを見て美容師が調整してください。'),
          const SizedBox(height: 24),
          const Text('おすすめスタイリング剤', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Product(name: '軽めワックス', price: '¥1,500〜2,000', reason: '自然な束感を作りやすい'),
          const Product(name: 'ヘアオイル', price: '¥1,200〜1,800', reason: '毛流れを整えやすい'),
          const Product(name: 'キープスプレー', price: '¥1,000〜1,500', reason: '前髪とトップをキープ'),
          const SizedBox(height: 20),
          const Text('30秒セット', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const StepRow('0〜5秒', 'ドライヤーで全体を乾かす'),
          const StepRow('5〜12秒', 'トップを自然に立ち上げる'),
          const StepRow('12〜20秒', 'スタイリング剤をなじませる'),
          const StepRow('20〜27秒', '毛流れを整える'),
          const StepRow('27〜30秒', '前髪・サイドを調整'),
        ],
      ),
    );
  }
}

class Product extends StatelessWidget {
  final String name, price, reason;
  const Product({super.key, required this.name, required this.price, required this.reason});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 8),
    child: ListTile(title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('$price\n$reason'),
      isThreeLine: true,
      trailing: const Icon(Icons.open_in_new)));
}

class StepRow extends StatelessWidget {
  final String time, text;
  const StepRow(this.time, this.text, {super.key});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 7),
    child: ListTile(leading: Text(time, style: const TextStyle(fontWeight: FontWeight.bold)), title: Text(text)));
}

class Notice extends StatelessWidget {
  final String text;
  const Notice({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: const Color(0xffeee8e0), borderRadius: BorderRadius.circular(13)),
    child: Text(text, style: const TextStyle(fontSize: 12, height: 1.5)),
  );
}
